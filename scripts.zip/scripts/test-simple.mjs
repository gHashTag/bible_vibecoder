console.log("🍎 Test Apple Glass"); import { ColorTemplate } from "./src/services/instagram-canvas.service.js"; console.log("ColorTemplate:", Object.keys(ColorTemplate));
